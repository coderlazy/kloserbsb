package com.androidnative.gms.listeners.quests;


import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.games.quest.Quest;
import com.google.android.gms.games.quest.QuestUpdateListener;

public class AN_QuestUpdateListener implements QuestUpdateListener{

	@Override
	public void onQuestCompleted(Quest quest) {
		
		Log.d(AndroidNativeBridge.TAG, "AN_QuestUpdateListener+");
	
		if(quest != null) {
			GameClientManager.GetInstance().updateQuest(quest);
			GameClientManager.GetInstance().claimQuest(quest);
		}

	}

	

}
