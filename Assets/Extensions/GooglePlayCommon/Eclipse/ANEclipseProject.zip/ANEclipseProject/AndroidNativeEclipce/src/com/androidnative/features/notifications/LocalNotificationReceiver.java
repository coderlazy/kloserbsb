package com.androidnative.features.notifications;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;

import com.androidnative.AndroidNativeBridge;

public class LocalNotificationReceiver extends BroadcastReceiver {

	
	private int NOTIFICATION_ID = 237628;
	
	@SuppressLint("NewApi")
	@Override
	public void onReceive(Context context, Intent intent) {
		
		Bundle extras 	= intent.getExtras();
		String title 	= extras.getString("title");
    	String message 	= extras.getString("message");
    	    	 
    	NotificationManager  mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        PendingIntent contentIntent = PendingIntent.getActivity(context, 0, new Intent(context, AndroidNativeBridge.class), 0);

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context)
	        .setSmallIcon(0x7f020000)//Unity Game Icon
	        .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE | Notification.DEFAULT_LIGHTS)
	        .setContentTitle(title)
	        .setStyle(new NotificationCompat.BigTextStyle()
	        .bigText(message))
	        .setContentText(message);

        mBuilder.setContentIntent(contentIntent).setAutoCancel(true);
        mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());
        
	}
}
