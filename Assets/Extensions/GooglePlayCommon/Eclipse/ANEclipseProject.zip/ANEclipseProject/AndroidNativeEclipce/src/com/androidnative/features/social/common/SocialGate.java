package com.androidnative.features.social.common;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore.Images;
import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.billing.util.Base64;
import com.androidnative.billing.util.Base64DecoderException;


public class SocialGate {

	
	@SuppressLint("NewApi")
	public static void Share(String caption, String message, String subject, String filters) {
		Log.d("AndroidNative", " SocialGate Share ");
		
		Intent shareIntent = new Intent();
		shareIntent.setAction(Intent.ACTION_SEND);
		shareIntent.setType("text/plain");
		shareIntent.putExtra(Intent.EXTRA_TEXT, message);
		shareIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
		StartIntent(shareIntent, caption, filters);
	}
	
	
	@SuppressLint("NewApi")
	public static void Share(String caption, String message,  String subject, String media,  String filters) {
		
		
		byte[] byteArray;
		try {
			byteArray = Base64.decode(media);
		
		
			 Bitmap bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
			 Uri image =  getImageUri(AndroidNativeBridge.GetInstance(), bmp);
		
			Intent shareIntent = new Intent();
			shareIntent.setAction(Intent.ACTION_SEND);
			shareIntent.setType("image/*");
			shareIntent.putExtra(Intent.EXTRA_TEXT, message);
			shareIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
			shareIntent.putExtra(Intent.EXTRA_STREAM, image);
			
			StartIntent(shareIntent, caption, filters);
			
			
		
		} catch (Base64DecoderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	public static void SendMailWithImage(String caption, String message,  String subject, String email, String media) {
		try {
			byte[] byteArray;
			byteArray = Base64.decode(media);
			
			
			 Bitmap bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
			 Uri image =  getImageUri(AndroidNativeBridge.GetInstance(), bmp);
		
			Intent shareIntent = new Intent();
			shareIntent.setAction(Intent.ACTION_SEND);
			shareIntent.setType("image/*");
			
			shareIntent.putExtra(android.content.Intent.EXTRA_EMAIL,new String[] { email });
			shareIntent.putExtra(Intent.EXTRA_TEXT, message);
			shareIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
			shareIntent.putExtra(Intent.EXTRA_STREAM, image);
			
			StartIntent(shareIntent, caption, "mail");
		} catch (Base64DecoderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void SendMail(String caption, String message,  String subject, String emails) {
		Intent shareIntent = new Intent();
		shareIntent.setAction(Intent.ACTION_SEND);
		shareIntent.setType("text/plain");
		shareIntent.putExtra(android.content.Intent.EXTRA_EMAIL,  emails.split(",") );
		
		shareIntent.putExtra(Intent.EXTRA_TEXT, message);
		shareIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
		StartIntent(shareIntent, caption, "mail");
		
	}
	
	
	
	@SuppressLint({ "NewApi", "DefaultLocale" })
	private static void StartIntent(Intent shareIntent, String caption, String filters) {
		if(filters.isEmpty()) {
			AndroidNativeBridge.GetInstance().startActivity(Intent.createChooser(shareIntent, caption));
		} else {
			ArrayList<String> filtersArray = new ArrayList<String>();
			String[] result = filters.split(",");

			for (String id : result) {
				filtersArray.add(id);
			}
			
			// gets the list of intents that can be loaded.
		    List<ResolveInfo> resInfo = AndroidNativeBridge.GetInstance().getPackageManager().queryIntentActivities(shareIntent, 0);
		    if (!resInfo.isEmpty()){
		        for (ResolveInfo info : resInfo) {
		        	for(String filterPattern : filtersArray) {
		        		if (info.activityInfo.packageName.toLowerCase().contains(filterPattern) || info.activityInfo.name.toLowerCase().contains(filterPattern) ) {
			            	shareIntent.setPackage(info.activityInfo.packageName);
			            }
		        	}
		        	
		            
		        }

		        AndroidNativeBridge.GetInstance().startActivity(Intent.createChooser(shareIntent, caption));
		    }
		    
		}
		
	}
	
	
	 public static Uri getImageUri(Context inContext, Bitmap inImage) {
		  ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		  inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
		  String path = Images.Media.insertImage(inContext.getContentResolver(), inImage, "Screenshot", null);
		  return Uri.parse(path);
	}
}
