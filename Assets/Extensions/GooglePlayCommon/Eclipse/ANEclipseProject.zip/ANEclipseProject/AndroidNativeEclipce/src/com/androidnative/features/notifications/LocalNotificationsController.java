package com.androidnative.features.notifications;

import java.util.Calendar;

import com.androidnative.AndroidNativeBridge;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.util.Log;



public class LocalNotificationsController {

	
	private static LocalNotificationsController _inctance = null;
	
	
	public static LocalNotificationsController GetInstance() {
		if (_inctance == null) {
			_inctance = new LocalNotificationsController();
		}

		return _inctance;
	}
	
	
	@SuppressLint("NewApi")
	public void scheduleNotification(String title, String message, int seconds) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.SECOND, seconds);

		Intent resultIntent = new Intent(AndroidNativeBridge.GetInstance(), LocalNotificationReceiver.class);
		resultIntent.putExtra("title", title);
		resultIntent.putExtra("message", message);
		
		AlarmManager am = (AlarmManager) AndroidNativeBridge.GetInstance().getSystemService(Activity.ALARM_SERVICE);
		// In reality, you would want to have a static variable for the request code instead of 192837
		PendingIntent sender = PendingIntent.getBroadcast(AndroidNativeBridge.GetInstance(), 123, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);
		// start the activity when the user clicks the notification text
		am.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), sender);
		
		Log.i(AndroidNativeBridge.TAG, "LocalNotificationsController scheduleNotification.");
	}
	
	
	@SuppressLint("NewApi")
	public void canselNotification(String title, String message) {
	
		Intent resultIntent = new Intent(AndroidNativeBridge.GetInstance(), LocalNotificationReceiver.class);
		resultIntent.putExtra("title", title);
		resultIntent.putExtra("message", message);
		
		AlarmManager am = (AlarmManager) AndroidNativeBridge.GetInstance().getSystemService(Activity.ALARM_SERVICE);
		// In reality, you would want to have a static variable for the request code instead of 192837
		PendingIntent sender = PendingIntent.getBroadcast(AndroidNativeBridge.GetInstance(), 123, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);
		// start the activity when the user clicks the notification text
		am.cancel(sender);
		
		Log.i(AndroidNativeBridge.TAG, "LocalNotificationsController canselNotification.");
	}
	
}
